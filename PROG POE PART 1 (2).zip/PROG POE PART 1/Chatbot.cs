using System;
using System.Threading;

namespace CyberSecurityBot
{
    public class Chatbot
    {
        private User user;
        private readonly (string Title, string Description)[] topics = new (string, string)[]
        {
            ("What is a Trojan?", "A Trojan is malware that disguises itself as legitimate software to trick users into running it."),
            ("Phishing", "Phishing is an attempt to obtain sensitive information by posing as a trustworthy entity, often via email."),
            ("Password security", "Use long, unique passwords and a password manager; enable two-factor authentication where possible."),
            ("Malware", "Malware is any software designed to harm or exploit systems, including viruses, worms, and Trojans."),
            ("Ransomware", "Ransomware encrypts your files and demands payment for the decryption key; keep backups and update software."),
            ("Viruses", "A virus attaches to programs or files and can replicate; keep antivirus software updated."),
            ("Spyware", "Spyware secretly gathers user information and can leak personal data; avoid suspicious downloads."),
            ("Social engineering", "Social engineering manipulates people into revealing confidential information or performing actions."),
            ("Safe browsing", "Use HTTPS sites, avoid suspicious links, and consider browser privacy/security extensions."),
            ("Software updates", "Keep your OS and applications patched to fix security vulnerabilities."),
            ("Two-factor authentication", "2FA adds an extra verification step to reduce the impact of stolen passwords."),
            ("Secure Wi-Fi", "Use strong Wi‑Fi passwords, WPA3/WPA2, and avoid using open networks for sensitive activities."),
            ("Backups", "Regularly back up important data to offline or cloud storage to recover from ransomware or failures."),
            ("Encryption", "Encryption protects data at rest and in transit; use encrypted channels and disk encryption where possible."),
            ("Safe downloads", "Only download software from trusted sources and verify digital signatures where available."),
            ("Privacy settings", "Review app and service privacy settings to limit data sharing and tracking.")
        };

        public void Start()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("===================================");
            Console.WriteLine("   CYBERSECURITY CHATBOT");
            Console.WriteLine("===================================");
            Console.ResetColor();

            TypingEffect("Welcome to the Cybersecurity Awareness Bot...\n");

            Console.Write("Enter your name: ");
            string name = Console.ReadLine();
            user = new User(name);

            Console.WriteLine($"Hello {user.Name}! Let's talk about staying safe online.");
            RunChat();
        }

        private void RunChat()
        {
            while (true)
            {
                Console.Write("\nYou: ");
                string input = Console.ReadLine()?.ToLower();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Please enter something.");
                    continue;
                }

                if (input == "exit")
                {
                    Console.WriteLine("Goodbye! Stay safe online.");
                    break;
                }
                else if (input.Contains("what can i ask") || input.Contains("what can i ask you") || input == "menu" || input == "help" || input.Contains("topics"))
                {
                    ShowMenu();
                    HandleMenuSelection();
                }
                else if (input == "how are you")
                {
                    Console.WriteLine("I'm just code, but I'm here to help you!");
                }
                else if (input.Contains("purpose"))
                {
                    Console.WriteLine("My purpose is to teach you cybersecurity awareness.");
                }
                else if (input.Contains("password"))
                {
                    Console.WriteLine("Use strong passwords with symbols and numbers.");
                }
                else if (input.Contains("phishing"))
                {
                    Console.WriteLine("Do not click suspicious links in emails.");
                }
                else if (input.Contains("virus"))
                {
                    Console.WriteLine("Install antivirus software and keep it updated.");
                }
                else if (input.Contains("update"))
                {
                    Console.WriteLine("Always keep your software and operating system updated.");
                }
                else
                {
                    Console.WriteLine("I didn't quite understand that.");
                }
            }
        }

        private void ShowMenu()
        {
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine("\n+-----------------------------------------------+");
            Console.WriteLine("|   Here are topics you can ask about:         |");
            Console.WriteLine("+-----------------------------------------------+");
            Console.ResetColor();
            for (int i = 0; i < topics.Length; i++)
            {
                Console.WriteLine($" {i + 1,2}. {topics[i].Title}");
            }
            Console.WriteLine("\nType the topic number to view the answer, or type 'back' to return to the chat.");
        }

        private void HandleMenuSelection()
        {
            while (true)
            {
                Console.Write("\nChoice (number or 'back'): ");
                string? choice = Console.ReadLine()?.Trim().ToLower();

                if (string.IsNullOrWhiteSpace(choice))
                {
                    Console.WriteLine("Please enter a topic number (1-16) or 'back' to return.");
                    continue;
                }

                if (choice == "back")
                {
                    Console.WriteLine("Returning to chat...");
                    return;
                }

                if (choice == "exit")
                {
                    Console.WriteLine("Goodbye! Stay safe online.");
                    Environment.Exit(0);
                }

                if (!int.TryParse(choice, out int num))
                {
                    Console.WriteLine("Please enter a valid topic number (1-16) or 'back'.");
                    continue;
                }

                if (num < 1 || num > topics.Length)
                {
                    Console.WriteLine("Invalid selection. Please enter a number between 1 and 16.");
                    continue;
                }

                // Display selected topic with a colored bordered box
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine("\n+-----------------------------------------------+");
                Console.WriteLine($"| {num}. {topics[num - 1].Title,-41} |");
                Console.WriteLine("+-----------------------------------------------+");
                Console.ResetColor();

                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine(topics[num - 1].Description);
                Console.ResetColor();

                // After showing the answer, loop continues so user can pick another number or 'back'
            }
        }

        private void TypingEffect(string message)
        {
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(50);
            }
        }
    }
}
