using System;
using System.Media;
using System.IO;

namespace CyberSecurityBot
{
    public class AudioPlayer
    {
        private readonly string filePath;

        public AudioPlayer(string path)
        {
            filePath = path;
        }

        public void PlayGreeting()
        {
            try
            {
                // Resolve relative paths to the application's base directory so files placed in bin\Debug... are found.
                string path = filePath;
                if (string.IsNullOrWhiteSpace(path))
                {
                    path = "greetings.wav";
                }

                if (!Path.IsPathRooted(path))
                {
                    path = Path.Combine(AppContext.BaseDirectory, path);
                }

                if (!File.Exists(path))
                {
                    Console.WriteLine($"Greeting audio not found at '{path}'.");
                    return;
                }

                using SoundPlayer player = new SoundPlayer(path);
                player.Play();
            }
            catch
            {
                Console.WriteLine("Greeting audio could not be played.");
            }
        }
    }
}
