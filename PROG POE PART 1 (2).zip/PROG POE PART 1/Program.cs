﻿using System;
using System.Media;

namespace CyberSecurityBot
{
    class Program
    {
        static void Main(string[] args)
        {
            // Play greeting audio
            AudioPlayer audio = new AudioPlayer("greetings.wav");
            audio.PlayGreeting();

            // ASCII Art
            Console.WriteLine(@"
   ____       _               ____        _   
  / ___|  ___| |__   ___     | __ )  ___ | |_ 
  \___ \ / __| '_ \ / _ \    |  _ \ / _ \| __|
   ___) | (__| | | |  __/    | |_) | (_) | |_ 
  |____/ \___|_| |_|\___|    |____/ \___/ \__|
");

            // Start chatbot
            Chatbot bot = new Chatbot();
            bot.Start();
        }
    }
}
